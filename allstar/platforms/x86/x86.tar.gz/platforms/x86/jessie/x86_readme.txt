# cd /srv
# run x86_allstar_asterisk_install.sh

# edit /etc/asterisk/iax.conf
#	change 1999 to your node number	

# edit /etc/asterisk/rpt.conf
#	change 1999 to your node number

# edit /etc/asterisk/extensions.conf
#	change 1999 to your node number

# reboot

